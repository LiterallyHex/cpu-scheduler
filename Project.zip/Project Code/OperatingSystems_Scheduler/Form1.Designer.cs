﻿namespace OperatingSystems_Scheduler
{
    partial class CPU_Scheduler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CPU_Scheduler));
            this.label2 = new System.Windows.Forms.Label();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.btn_OK = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_select = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.buttonAbout = new System.Windows.Forms.Button();
            this.buttonHelp = new System.Windows.Forms.Button();
            this.buttonTiming = new System.Windows.Forms.Button();
            this.buttonAlgo = new System.Windows.Forms.Button();
            this.buttonScheduling = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.aboutControl1 = new OperatingSystems_Scheduler.AboutControl();
            this.helpControl1 = new OperatingSystems_Scheduler.HelpControl();
            this.timingControl1 = new OperatingSystems_Scheduler.TimingControl();
            this.algoControl1 = new OperatingSystems_Scheduler.AlgoControl();
            this.homeControl1 = new OperatingSystems_Scheduler.HomeControl();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(237, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Number of Processes";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txt_num
            // 
            this.txt_num.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.txt_num.Location = new System.Drawing.Point(406, 70);
            this.txt_num.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(180, 26);
            this.txt_num.TabIndex = 1;
            // 
            // btn_OK
            // 
            this.btn_OK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.btn_OK.FlatAppearance.BorderSize = 0;
            this.btn_OK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OK.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.btn_OK.ForeColor = System.Drawing.Color.White;
            this.btn_OK.Location = new System.Drawing.Point(406, 136);
            this.btn_OK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(87, 28);
            this.btn_OK.TabIndex = 0;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = false;
            this.btn_OK.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.label3.Location = new System.Drawing.Point(237, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Scheduling Algorithm";
            // 
            // cmb_select
            // 
            this.cmb_select.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.cmb_select.FormattingEnabled = true;
            this.cmb_select.Items.AddRange(new object[] {
            "First Come First Served",
            "Shortest Job first (NP)",
            "Shortest Job first (P)",
            "Priority (NP)",
            "Priority (P)",
            "Round Robin"});
            this.cmb_select.Location = new System.Drawing.Point(406, 100);
            this.cmb_select.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmb_select.Name = "cmb_select";
            this.cmb_select.Size = new System.Drawing.Size(273, 28);
            this.cmb_select.TabIndex = 6;
            this.cmb_select.SelectedIndexChanged += new System.EventHandler(this.cmb_select_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(499, 136);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 28);
            this.button2.TabIndex = 7;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(592, 136);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 28);
            this.button1.TabIndex = 8;
            this.button1.Text = "Help";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.SidePanel);
            this.panel1.Controls.Add(this.buttonAbout);
            this.panel1.Controls.Add(this.buttonHelp);
            this.panel1.Controls.Add(this.buttonTiming);
            this.panel1.Controls.Add(this.buttonAlgo);
            this.panel1.Controls.Add(this.buttonScheduling);
            this.panel1.Controls.Add(this.buttonHome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(209, 686);
            this.panel1.TabIndex = 9;
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(41)))), ((int)(((byte)(63)))));
            this.SidePanel.Location = new System.Drawing.Point(0, 136);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(10, 56);
            this.SidePanel.TabIndex = 11;
            // 
            // buttonAbout
            // 
            this.buttonAbout.FlatAppearance.BorderSize = 0;
            this.buttonAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAbout.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAbout.ForeColor = System.Drawing.Color.White;
            this.buttonAbout.Image = ((System.Drawing.Image)(resources.GetObject("buttonAbout.Image")));
            this.buttonAbout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAbout.Location = new System.Drawing.Point(12, 446);
            this.buttonAbout.Name = "buttonAbout";
            this.buttonAbout.Size = new System.Drawing.Size(197, 56);
            this.buttonAbout.TabIndex = 16;
            this.buttonAbout.Text = "     About";
            this.buttonAbout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonAbout.UseVisualStyleBackColor = true;
            this.buttonAbout.Click += new System.EventHandler(this.buttonAbout_Click);
            // 
            // buttonHelp
            // 
            this.buttonHelp.FlatAppearance.BorderSize = 0;
            this.buttonHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHelp.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHelp.ForeColor = System.Drawing.Color.White;
            this.buttonHelp.Image = ((System.Drawing.Image)(resources.GetObject("buttonHelp.Image")));
            this.buttonHelp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHelp.Location = new System.Drawing.Point(12, 384);
            this.buttonHelp.Name = "buttonHelp";
            this.buttonHelp.Size = new System.Drawing.Size(197, 56);
            this.buttonHelp.TabIndex = 15;
            this.buttonHelp.Text = "     Help";
            this.buttonHelp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonHelp.UseVisualStyleBackColor = true;
            this.buttonHelp.Click += new System.EventHandler(this.buttonHelp_Click);
            // 
            // buttonTiming
            // 
            this.buttonTiming.FlatAppearance.BorderSize = 0;
            this.buttonTiming.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTiming.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTiming.ForeColor = System.Drawing.Color.White;
            this.buttonTiming.Image = ((System.Drawing.Image)(resources.GetObject("buttonTiming.Image")));
            this.buttonTiming.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTiming.Location = new System.Drawing.Point(12, 322);
            this.buttonTiming.Name = "buttonTiming";
            this.buttonTiming.Size = new System.Drawing.Size(197, 56);
            this.buttonTiming.TabIndex = 14;
            this.buttonTiming.Text = "     Timing Terms";
            this.buttonTiming.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonTiming.UseVisualStyleBackColor = true;
            this.buttonTiming.Click += new System.EventHandler(this.buttonTiming_Click);
            // 
            // buttonAlgo
            // 
            this.buttonAlgo.FlatAppearance.BorderSize = 0;
            this.buttonAlgo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAlgo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAlgo.ForeColor = System.Drawing.Color.White;
            this.buttonAlgo.Image = ((System.Drawing.Image)(resources.GetObject("buttonAlgo.Image")));
            this.buttonAlgo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAlgo.Location = new System.Drawing.Point(12, 260);
            this.buttonAlgo.Name = "buttonAlgo";
            this.buttonAlgo.Size = new System.Drawing.Size(197, 56);
            this.buttonAlgo.TabIndex = 13;
            this.buttonAlgo.Text = "     Algorithms";
            this.buttonAlgo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonAlgo.UseVisualStyleBackColor = true;
            this.buttonAlgo.Click += new System.EventHandler(this.buttonAlgo_Click);
            // 
            // buttonScheduling
            // 
            this.buttonScheduling.FlatAppearance.BorderSize = 0;
            this.buttonScheduling.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonScheduling.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonScheduling.ForeColor = System.Drawing.Color.White;
            this.buttonScheduling.Image = ((System.Drawing.Image)(resources.GetObject("buttonScheduling.Image")));
            this.buttonScheduling.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonScheduling.Location = new System.Drawing.Point(12, 198);
            this.buttonScheduling.Name = "buttonScheduling";
            this.buttonScheduling.Size = new System.Drawing.Size(197, 56);
            this.buttonScheduling.TabIndex = 12;
            this.buttonScheduling.Text = "     Scheduling";
            this.buttonScheduling.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonScheduling.UseVisualStyleBackColor = true;
            this.buttonScheduling.Click += new System.EventHandler(this.buttonScheduling_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.FlatAppearance.BorderSize = 0;
            this.buttonHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHome.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.White;
            this.buttonHome.Image = ((System.Drawing.Image)(resources.GetObject("buttonHome.Image")));
            this.buttonHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHome.Location = new System.Drawing.Point(12, 136);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(197, 56);
            this.buttonHome.TabIndex = 11;
            this.buttonHome.Text = "     Home";
            this.buttonHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonHome.UseVisualStyleBackColor = true;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(41)))), ((int)(((byte)(63)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.buttonExit);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(209, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1101, 43);
            this.panel2.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(491, 30);
            this.label1.TabIndex = 11;
            this.label1.Text = "Process Scheduling Algorithms Simulator";
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(41)))), ((int)(((byte)(63)))));
            this.buttonExit.FlatAppearance.BorderSize = 0;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.Color.White;
            this.buttonExit.Image = ((System.Drawing.Image)(resources.GetObject("buttonExit.Image")));
            this.buttonExit.Location = new System.Drawing.Point(1057, 4);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(39, 35);
            this.buttonExit.TabIndex = 17;
            this.buttonExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // aboutControl1
            // 
            this.aboutControl1.Location = new System.Drawing.Point(209, 50);
            this.aboutControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aboutControl1.Name = "aboutControl1";
            this.aboutControl1.Size = new System.Drawing.Size(1101, 636);
            this.aboutControl1.TabIndex = 15;
            this.aboutControl1.Load += new System.EventHandler(this.aboutControl1_Load);
            // 
            // helpControl1
            // 
            this.helpControl1.Location = new System.Drawing.Point(209, 50);
            this.helpControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.helpControl1.Name = "helpControl1";
            this.helpControl1.Size = new System.Drawing.Size(1101, 636);
            this.helpControl1.TabIndex = 14;
            // 
            // timingControl1
            // 
            this.timingControl1.Location = new System.Drawing.Point(209, 50);
            this.timingControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.timingControl1.Name = "timingControl1";
            this.timingControl1.Size = new System.Drawing.Size(1101, 636);
            this.timingControl1.TabIndex = 13;
            // 
            // algoControl1
            // 
            this.algoControl1.Location = new System.Drawing.Point(209, 50);
            this.algoControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.algoControl1.Name = "algoControl1";
            this.algoControl1.Size = new System.Drawing.Size(1101, 636);
            this.algoControl1.TabIndex = 12;
            // 
            // homeControl1
            // 
            this.homeControl1.Location = new System.Drawing.Point(209, 50);
            this.homeControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.homeControl1.Name = "homeControl1";
            this.homeControl1.Size = new System.Drawing.Size(1101, 636);
            this.homeControl1.TabIndex = 11;
            // 
            // CPU_Scheduler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1310, 686);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cmb_select);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_num);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.aboutControl1);
            this.Controls.Add(this.helpControl1);
            this.Controls.Add(this.timingControl1);
            this.Controls.Add(this.algoControl1);
            this.Controls.Add(this.homeControl1);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "CPU_Scheduler";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CPU Scheduler";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_select;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonAbout;
        private System.Windows.Forms.Button buttonHelp;
        private System.Windows.Forms.Button buttonTiming;
        private System.Windows.Forms.Button buttonAlgo;
        private System.Windows.Forms.Button buttonScheduling;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Label label1;
        private HomeControl homeControl1;
        private AlgoControl algoControl1;
        private TimingControl timingControl1;
        private HelpControl helpControl1;
        private AboutControl aboutControl1;
    }
}

